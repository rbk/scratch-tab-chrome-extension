# Scratch Tab

Chrome new tab override with a textarea that saves and syncs text across tabs.

## Change log

04/04/2018 - Added invert code
